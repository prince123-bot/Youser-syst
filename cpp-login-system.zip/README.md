# C++ Login and Password System 🔐

A simple login and registration system in C++ using file I/O.

## Features

- Register with username and password
- Login with verification
- Stores credentials in a text file

## How to Compile and Run

```bash
g++ main.cpp -o login
./login
```

## Author

Made with ❤️ by [Your Name]
