#include <iostream>
#include <fstream>
#include <string>
using namespace std;

void registerUser() {
    string username, password;
    cout << "Register
";
    cout << "Enter username: ";
    cin >> username;
    cout << "Enter password: ";
    cin >> password;

    ofstream file("database.txt", ios::app);
    file << username << " " << password << endl;
    file.close();

    cout << "User registered successfully!
";
}

bool loginUser() {
    string username, password, u, p;
    cout << "Login
";
    cout << "Enter username: ";
    cin >> username;
    cout << "Enter password: ";
    cin >> password;

    ifstream file("database.txt");
    while (file >> u >> p) {
        if (u == username && p == password) {
            file.close();
            return true;
        }
    }
    file.close();
    return false;
}

int main() {
    int choice;
    cout << "1. Register
2. Login
Enter choice: ";
    cin >> choice;

    if (choice == 1) {
        registerUser();
    } else if (choice == 2) {
        if (loginUser()) {
            cout << "Login successful!
";
        } else {
            cout << "Invalid username or password.
";
        }
    } else {
        cout << "Invalid choice.
";
    }

    return 0;
}
